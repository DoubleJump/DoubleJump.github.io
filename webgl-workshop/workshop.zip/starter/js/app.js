var app = 
{
	assets:
	{
		meshes: {},
		textures: {},
		materials: {},
		load_count: 0,
		total: 0,
	},
};

var app = {};

window.addEventListener('load', start);

function start() 
{
	// Keep track of time (we'll use this later on)
	app.time = new THREE.Clock();

	// Scene
	app.scene = new THREE.Scene();

	// Camera
	var field_of_view = 60;
	var aspect_ratio = window.innerWidth / window.innerHeight;
	var near_clip = 0.01;
	var far_clip = 100;

	app.camera = new THREE.PerspectiveCamera(
		field_of_view, 
		aspect_ratio, 
		near_clip, 
		far_clip);

	// Pull the camera away from the center a bit
	app.camera.position.set(0,0,1.5);

	// Create a cube
	var geometry = new THREE.BoxGeometry(1,1,1);
	var material = new THREE.MeshBasicMaterial({color: "#FFFFFF"});
	app.cube = new THREE.Mesh(geometry, material);
	app.scene.add(cube);

	// Create a renderer
	var renderer = new THREE.WebGLRenderer();
	renderer.setSize(window.innerWidth, window.innerHeight);
	document.querySelector('.webgl').appendChild(renderer.domElement);
	app.renderer = renderer;

	// Start update loop
	requestAnimationFrame(update);
}

function update(t)
{
	// Continue update loop
	requestAnimationFrame(update);

	// Spin the cube
	app.cube.rotation.x += 0.01;
	app.cube.rotation.y += 0.01;

	// Tell THREEjs to render the scene using our camera
	app.renderer.render(app.scene, app.camera);
}